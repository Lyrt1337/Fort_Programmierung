# print(ord("a"))
# print(chr(97))


# def countColors(path):
#     pass
#
# with open("world.jpg", "rb") as p:
#     read_picture = p.read()
#     print(read_picture)


import numpy as np
from PIL import Image
import random as rnd
from matplotlib import pyplot as plt

imgPath = "test.jpg"

img = Image.open(imgPath)
uniqueColors = []

# print(img)
# img.show()

w, h = img.size
for x in range(w):
    for y in range(h):
        pixel = img.getpixel((x, y))
        uniqueColors.append(pixel)




totalUniqueColors = len(uniqueColors)

print("Unique colors: ", totalUniqueColors)


img = Image.open(imgPath)

max_colors = totalUniqueColors

with open("pixels.txt", "w") as b:
    b.write(str(img.getcolors(max_colors)))


# print(img.getcolors(max_colors))




# counting specific colors
# col = 0
#
# for pixel in img.getdata():
#     if pixel == (1, 15, 0): # if your image is RGB (if RGBA, (0, 0, 0, 255) or so
#         col += 1
#
# print('col=' + str(col))

all_colors = img.getcolors(max_colors)

list1 = []
for i in all_colors:
    list1.append(i[0])
    list1.sort(reverse=True)

list2 = list1[0:10]
# print(list2)
colors = []
for i in all_colors:
    if i[0] in list2:
        colors.append(i[1])

# print("colors: ", colors)

# switching pixels for top10
for i in range(len(uniqueColors)):
    if uniqueColors[i] not in colors:
        uniqueColors[i] = rnd.choice(colors)

# img_out = Image.fromarray(colors, 'RGB')
# img_out.save('my.png')
# img_out.show()


# plt.imshow(uniqueColors, interpolation='nearest')
# plt.show()

# print("neues bild", uniqueColors)

# plt.imsave('filename.png', np.array(result).reshape(w, 768), cmap=cm.gray
plt.imsave('filename.png', np.array(uniqueColors).reshape(512, 384))
plt.imshow(np.array(uniqueColors).reshape(512, 384))
